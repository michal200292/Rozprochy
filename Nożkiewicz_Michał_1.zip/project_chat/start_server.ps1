javac src\*.java
java src.Server server 8008